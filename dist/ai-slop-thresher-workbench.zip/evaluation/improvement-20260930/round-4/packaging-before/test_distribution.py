"""Distribution safety and harness separation; no live user installation."""

import importlib.util
import io
import json
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("distribution", ROOT / "scripts/distribute.py")
distribution = importlib.util.module_from_spec(spec)
spec.loader.exec_module(distribution)


class DistributionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.base = Path(self.temp.name)
        self.source = self.base / "source"
        for name in distribution.SKILLS:
            folder = self.source / "skills" / name
            folder.mkdir(parents=True)
            body = f"---\nname: {name}\ndescription: Test skill\nmetadata:\n  version: \"1.2.0\"\n---\n\n"
            if name == "thresh":
                body += "[canonical](../ai-slop-thresher/SKILL.md)\n"
            else:
                (folder / "references").mkdir()
                (folder / "references/fixture.md").write_text("Fixture\n", encoding="utf-8")
                body += "[reference](references/fixture.md)\n"
            (folder / "SKILL.md").write_text(body, encoding="utf-8")
            metadata = self.source / "integrations/codex/agents" / name
            metadata.mkdir(parents=True)
            (metadata / "openai.yaml").write_text("interface:\n  display_name: Test\n", encoding="utf-8")
        for name in distribution.LEGAL:
            (self.source / name).write_text("Legal notice\n", encoding="utf-8")
        market = self.source / ".agents/plugins"
        market.mkdir(parents=True)
        (market / "marketplace.json").write_text(json.dumps({"plugins": [{"source": {"source": "local", "path": "./plugins/codex/ai-slop-thresher"}}]}), encoding="utf-8")

    def tearDown(self):
        self.temp.cleanup()

    def install(self, **kwargs):
        return distribution.install_skills(root=self.source, home=self.base / "home", **kwargs)

    def test_all_harness_user_paths_dry_run(self):
        for target, config in distribution.TARGETS.items():
            result = self.install(target=target)
            self.assertTrue(result["dry_run"])
            self.assertEqual(Path(result["destination"]), self.base / "home" / config["user"])
        self.assertFalse((self.base / "home").exists())

    def test_all_harness_project_installations(self):
        for target, config in distribution.TARGETS.items():
            project = self.base / target
            result = self.install(target=target, scope="project", project=project, apply=True)
            destination = project / config["project"]
            self.assertFalse(result["settings_modified"])
            self.assertTrue((destination / "thresh/SKILL.md").is_file())
            self.assertTrue((destination / "ai-slop-thresher/references/fixture.md").is_file())
            self.assertTrue((destination / "thresh/NOTICE").is_file())
            self.assertEqual((destination / "ai-slop-thresher/SKILL.md").read_bytes(), (self.source / "skills/ai-slop-thresher/SKILL.md").read_bytes())
            self.assertEqual((destination / "thresh/NOTICE").read_bytes(), (self.source / "NOTICE").read_bytes())
            self.assertEqual((destination / "ai-slop-thresher/agents/openai.yaml").exists(), target == "codex")
            self.assertEqual((destination / "thresh/agents/openai.yaml").exists(), target == "codex")

    def test_generic_destination_and_alias_sibling(self):
        destination = self.base / "explicit"
        self.install(target="generic", destination=destination, apply=True)
        self.assertTrue((destination / "thresh/../ai-slop-thresher/SKILL.md").is_file())

    def test_generic_requires_destination(self):
        with self.assertRaises(distribution.DistributionError):
            self.install(target="generic")

    def test_scope_arguments_cannot_silently_conflict(self):
        for kwargs in ({"scope": "project"}, {"project": self.base}, {"destination": self.base, "scope": "project", "project": self.base}):
            with self.subTest(kwargs=kwargs), self.assertRaises(distribution.DistributionError):
                self.install(target="codex", **kwargs)

    def test_existing_skill_prevents_both_installs(self):
        destination = self.base / "existing"
        existing = destination / "thresh"
        existing.mkdir(parents=True)
        original = existing / "SKILL.md"
        original.write_text("USER EDIT", encoding="utf-8")
        with self.assertRaises(distribution.DistributionError):
            self.install(target="generic", destination=destination, apply=True)
        self.assertEqual(original.read_text(encoding="utf-8"), "USER EDIT")
        self.assertFalse((destination / "ai-slop-thresher").exists())

    def make_link(self, link, target, directory=True):
        try:
            link.symlink_to(target, target_is_directory=directory)
        except OSError:
            self.skipTest("symlink creation unavailable on this host")

    def test_linked_destination_ancestor_is_rejected(self):
        real = self.base / "real"
        real.mkdir()
        link = self.base / "link"
        self.make_link(link, real)
        with self.assertRaises(distribution.DistributionError):
            self.install(target="generic", destination=link / "skills", apply=True)
        self.assertEqual(list(real.iterdir()), [])

    def test_dangling_skill_link_is_rejected(self):
        destination = self.base / "dangling"
        destination.mkdir()
        self.make_link(destination / "thresh", self.base / "missing")
        with self.assertRaises(distribution.DistributionError):
            self.install(target="generic", destination=destination, apply=True)
        self.assertFalse((destination / "ai-slop-thresher").exists())

    def test_source_symlink_rejected(self):
        file = self.source / "skills/ai-slop-thresher/references/fixture.md"
        file.unlink()
        target = self.base / "external.md"
        target.write_text("External", encoding="utf-8")
        self.make_link(file, target, directory=False)
        with self.assertRaises(distribution.DistributionError):
            distribution.portable_files(self.source)

    def test_windows_junction_destination_rejected(self):
        if sys.platform != "win32" or not hasattr(Path, "is_junction"):
            self.skipTest("Windows junction test requires Windows Python 3.12+")
        real = self.base / "junction-target"
        real.mkdir()
        link = self.base / "junction"
        command = subprocess.run(["cmd", "/c", "mklink", "/J", str(link), str(real)], capture_output=True, text=True)
        if command.returncode:
            self.skipTest("junction creation unavailable")
        try:
            with self.assertRaises(distribution.DistributionError):
                self.install(target="generic", destination=link / "skills", apply=True)
            self.assertEqual(list(real.iterdir()), [])
        finally:
            link.rmdir()

    def test_portable_rejects_codex_metadata(self):
        metadata = self.source / "skills/thresh/agents"
        metadata.mkdir()
        (metadata / "openai.yaml").write_text("unexpected", encoding="utf-8")
        with self.assertRaises(distribution.DistributionError):
            distribution.portable_files(self.source)

    def test_local_reference_must_be_present(self):
        (self.source / "skills/ai-slop-thresher/references/fixture.md").unlink()
        with self.assertRaises(distribution.DistributionError):
            distribution.portable_files(self.source)

    def test_local_reference_cannot_escape_package(self):
        file = self.source / "skills/thresh/SKILL.md"
        file.write_text(file.read_text(encoding="utf-8") + "[private](../../secrets.md)\n", encoding="utf-8")
        with self.assertRaises(distribution.DistributionError):
            distribution.portable_files(self.source)

    def test_metadata_name_must_match_directory(self):
        file = self.source / "skills/thresh/SKILL.md"
        file.write_text(file.read_text(encoding="utf-8").replace("name: thresh", "name: impostor"), encoding="utf-8")
        with self.assertRaises(distribution.DistributionError):
            distribution.portable_files(self.source)

    def test_projection_rebuild_and_stale_check(self):
        distribution.build_plugin(root=self.source, apply=True)
        distribution.check_plugin(root=self.source)
        file = self.source / "skills/ai-slop-thresher/references/fixture.md"
        file.write_text("Updated reference\n", encoding="utf-8")
        with self.assertRaises(distribution.DistributionError):
            distribution.check_plugin(root=self.source)
        distribution.build_plugin(root=self.source, apply=True)
        distribution.check_plugin(root=self.source)

    def test_build_defaults_to_no_changes(self):
        distribution.build_plugin(root=self.source)
        self.assertFalse((self.source / "plugins").exists())

    def test_check_rejects_missing_marketplace_target(self):
        output = self.base / "custom"
        distribution.build_plugin(root=self.source, output=output, apply=True)
        with self.assertRaises(distribution.DistributionError):
            distribution.check_plugin(root=self.source, output=output)

    def test_check_rejects_wrong_marketplace_path(self):
        distribution.build_plugin(root=self.source, apply=True)
        marketplace = self.source / ".agents/plugins/marketplace.json"
        marketplace.write_text(json.dumps({"plugins": [{"source": {"source": "local", "path": "../../wrong"}}]}), encoding="utf-8")
        with self.assertRaises(distribution.DistributionError):
            distribution.check_plugin(root=self.source)

    def test_build_rejects_unmanaged_output(self):
        output = self.base / "unmanaged"
        output.mkdir()
        (output / "user.md").write_text("user", encoding="utf-8")
        with self.assertRaises(distribution.DistributionError):
            distribution.build_plugin(root=self.source, output=output, apply=True)
        self.assertEqual((output / "user.md").read_text(), "user")

    def test_build_rejects_edited_generated_output(self):
        output = self.base / "generated"
        distribution.build_plugin(root=self.source, output=output, apply=True)
        (output / "NOTICE").write_text("local edit", encoding="utf-8")
        with self.assertRaises(distribution.DistributionError):
            distribution.build_plugin(root=self.source, output=output, apply=True)

    def test_separate_self_contained_reproducible_archives(self):
        output = self.base / "archives"
        result = distribution.package(root=self.source, output=output)
        self.assertFalse(output.exists())
        self.assertTrue(result["dry_run"])
        first = distribution.package(root=self.source, output=output, apply=True)
        second = distribution.package(root=self.source, output=output, apply=True)
        self.assertEqual(first, second)
        with zipfile.ZipFile(output / "ai-slop-thresher-portable.zip") as archive:
            self.assertFalse(any("agents/" in name or ".codex-plugin" in name for name in archive.namelist()))
            self.assertTrue(all(name in archive.namelist() for name in distribution.LEGAL))
        with zipfile.ZipFile(output / "ai-slop-thresher-codex-plugin.zip") as archive:
            self.assertIn(".codex-plugin/plugin.json", archive.namelist())
            self.assertIn("skills/thresh/agents/openai.yaml", archive.namelist())
            manifest = json.loads(archive.read(".codex-plugin/plugin.json"))
            self.assertEqual(manifest["skills"], "./skills/")
            self.assertEqual(manifest["version"], "1.2.0")
            self.assertTrue(all(name in archive.namelist() for name in distribution.LEGAL))
        self.assertEqual((output / "ai-slop-thresher.zip").read_bytes(), (output / "ai-slop-thresher-portable.zip").read_bytes())

    def test_archive_external_members_do_not_appear(self):
        files = distribution.plugin_files(self.source)
        blob = distribution.archive_bytes(files)
        with zipfile.ZipFile(io.BytesIO(blob)) as archive:
            self.assertEqual({name: archive.read(name) for name in archive.namelist()}, files)


if __name__ == "__main__":
    unittest.main()
